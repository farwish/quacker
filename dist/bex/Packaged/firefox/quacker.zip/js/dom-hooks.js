// Hooks added here have a bridge allowing communication between the Web Page and the BEX Content Script.

export default function attachDomHooks (bridge) {
}
